package org.catours.tourfinder;

import java.text.NumberFormat;

import org.catours.tourfinder.db.TourItem;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class TourDetailActivity extends Activity {

	TourItem mTour;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_tour_detail);

		getActionBar().setDisplayHomeAsUpEnabled(true);

//		Check for map availability

		Bundle b = getIntent().getExtras();
		mTour = b.getParcelable(".model.Tour");

		displayTourDetails();

	}

	private void displayTourDetails() {

		TextView tv = (TextView) findViewById(R.id.titleText);
		tv.setText(mTour.getTitle());

		NumberFormat nf = NumberFormat.getCurrencyInstance();
		tv = (TextView) findViewById(R.id.priceText);
		tv.setText(nf.format(mTour.getPrice()));

		tv = (TextView) findViewById(R.id.descText);
		tv.setText(mTour.getDescription());

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_tour_detail, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_goto_action :
//			Go to external mapping app
			sendToActionIntent();
			break;
		case android.R.id.home:
//			User pressed the 'Up' button on the action bar
			finish();
			break;
		}
		return false;
	}

public void sendToActionIntent() {
//	Send to another mapping app
}

}
