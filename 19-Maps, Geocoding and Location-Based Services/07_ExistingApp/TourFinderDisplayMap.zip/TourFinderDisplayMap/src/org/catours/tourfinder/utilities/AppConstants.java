package org.catours.tourfinder.utilities;

public class AppConstants {

	public static final int TOUR_DETAIL_ACTIVITY = 9001;
	public static final int GPS_ERRORDIALOG_REQUEST = 9002;

}
