package org.catours.tourfinder;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.NumberFormat;

import org.catours.tourfinder.db.TourItem;
import org.catours.tourfinder.utilities.GooglePlayServiceUtility;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.MarkerOptions;

public class TourDetailActivity extends Activity {

	TourItem mTour;
	boolean mShowMap;
	private GoogleMap mMap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_tour_detail);

		getActionBar().setDisplayHomeAsUpEnabled(true);

		mShowMap = GooglePlayServiceUtility.isPlayServiceAvailable(this) && initMap();

		Bundle b = getIntent().getExtras();
		mTour = b.getParcelable(".model.Tour");

		displayTourDetails();

	}

	private void displayTourDetails() {

		TextView tv = (TextView) findViewById(R.id.titleText);
		tv.setText(mTour.getTitle());

		NumberFormat nf = NumberFormat.getCurrencyInstance();
		tv = (TextView) findViewById(R.id.priceText);
		tv.setText(nf.format(mTour.getPrice()));

		tv = (TextView) findViewById(R.id.descText);
		tv.setText(mTour.getDescription());

if (mShowMap) {
	CameraUpdate update = CameraUpdateFactory.newLatLngZoom(mTour.getLatLng(), 5);
	mMap.moveCamera(update);
	
//			Decide what text to display on the marker
	String markerTitle = 
			mTour.getMarkerText().equals("") ?
			mTour.getTitle() : 
			mTour.getMarkerText();
//			Add a marker to the map. anchor() pins the center of the icon to the location
	mMap.addMarker(new MarkerOptions()
		.position(mTour.getLatLng())
		.title(markerTitle)
		.anchor(.5f, .5f)
		.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_starmarker))
	);
}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_tour_detail, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_goto_action :
//			Go to external mapping app
			sendToActionIntent();
			break;
		case android.R.id.home:
//			User pressed the 'Up' button on the action bar
			finish();
			break;
		}
		return false;
	}

	private boolean initMap() {
		if (mMap == null) {
			MapFragment mapFrag = 
					(MapFragment)getFragmentManager().findFragmentById(R.id.map); 
			mMap = mapFrag.getMap();
		}
		return (mMap != null);
	}

public void sendToActionIntent() {
	StringBuilder uri = new StringBuilder( "geo:" + 
			mTour.getLatitude() + "," + mTour.getLongitude() + "?z=12");

	//		If the tour record provides marker text, pass that text to Google Maps as a query
	if (!mTour.getMarkerText().equals("")) {
		try{
			uri.append("&q=" + URLEncoder.encode(mTour.getMarkerText(), "UTF-8") );
		}
		catch(UnsupportedEncodingException e) {
			//do nothing, just continue onward
		}
	}

	//		Create an action intent and pass the uri. If only Google Maps has registered
	//		for the 'geo:' prefix, it starts; if more than on app has registered 
	//		(Google Earth for example), user will be asked to select a target app
	Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri.toString()));
	startActivity(i); 
}

}
